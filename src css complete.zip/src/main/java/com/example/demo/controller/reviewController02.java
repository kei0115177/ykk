package com.example.demo.controller;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.example.demo.Entity.review;
import com.example.demo.repository.reviewRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class reviewController02 {//このクラスはwebリクエストを受け取るコントローラーです

	/**
	 *  Repositoryインスタンス（DB操作用）
	 */
	private final reviewRepository reviewRepository;

	// Azure Text Analytics APIのエンドポイントとキーです。
	private final String AZURE_ENDPOINT = "https://bunnseki01.cognitiveservices.azure.com/";
	private final String AZURE_KEY = "5zB3UvMufpMCPzYmX4fTNYdSIj6wZBSxISlWmU5N5woHq8h6wmYNJQQJ99BFACYeBjFXJ3w3AAAaACOGdPMC";

	// コンストラクタでrepositoryを注入します。
	public reviewController02(reviewRepository reviewRepository) {
		this.reviewRepository = reviewRepository;
	}

	/**
	 * メソッド名: showForm
	 * レビューフォーム画面を表示します。
	 * 投稿成功時はパラメータ success に応じてメッセージを表示します。
	 *
	 * @param success リクエストパラメータ。投稿成功のフラグ（nullの場合はメッセージなし）
	 * @param model HTMLへ値を渡すためのModelオブジェクト
	 * @return String ビュー名（"reviewForm"を返し、reviewForm.htmlを表示）
	 */
	@GetMapping("/reviewForm")
	public String showForm(@RequestParam(required = false) String success, Model model) {
		if (success != null) {
			model.addAttribute("message", "レビューを投稿しました！");
		}
		return "reviewForm"; // reviewForm.htmlを表示
	}

	/**
	 * メソッド名: categorizeProduct
	 * 商品名に基づいてカテゴリを判定します。
	 * 家電、日用品、食品、ファッション、家具、その他に分類します。
	 *
	 * @param product 商品名の文字列
	 * @return String 判定されたカテゴリ名
	 */
	private String categorizeProduct(String product) {
		// カテゴリとキーワードのマッピング
		Map<String, List<String>> map = new HashMap<>();
		map.put("家電", List.of("テレビ", "冷蔵庫", "エアコン", "電子レンジ", "掃除機"));
		map.put("日用品", List.of("シャンプー", "洗剤", "ティッシュ", "歯ブラシ"));
		map.put("食品", List.of("チョコレート", "インスタントラーメン", "ジュース", "コーヒー"));
		map.put("ファッション", List.of("シャツ", "靴", "バッグ", "腕時計"));
		map.put("家具", List.of("椅子", "ソファ", "机", "ベッド"));

		String lower = product.toLowerCase();
		// キーワードを含んでいれば該当カテゴリを返します。
		for (var entry : map.entrySet()) {
			for (String keyword : entry.getValue()) {
				if (lower.contains(keyword.toLowerCase())) {
					return entry.getKey(); // 該当カテゴリを返す
				}
			}
		}
		return "その他"; // どれにも当てはまらなければ「その他」に分類される。
	}

	/**
	 * メソッド名: analyzeSentiment
	 * Azure Text Analytics APIを使ってテキストの感情分析を行います。
	 *
	 * @param text 分析対象のテキスト
	 * @return String 感情分析結果（"positive", "negative", "neutral"など）
	 */
	private String analyzeSentiment(String text) {
		try {
			RestTemplate restTemplate = new RestTemplate();
			String url = AZURE_ENDPOINT + "/text/analytics/v3.1/sentiment";

			// APIリクエストヘッダーを設定
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Ocp-Apim-Subscription-Key", AZURE_KEY);

			// APIリクエストボディをJSON形式で作成
			String body = "{ \"documents\": [ { \"id\": \"1\", \"language\": \"ja\", \"text\": \""
					+ text.replace("\"", "\\\"") + "\" } ] }";

			HttpEntity<String> entity = new HttpEntity<>(body, headers);

			// POSTリクエストで感情分析APIを呼び出す
			ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);

			if (response.getStatusCode() == HttpStatus.OK) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response.getBody());
				JsonNode sentimentNode = root.path("documents").get(0).path("sentiment");
				if (!sentimentNode.isMissingNode()) {
					String sentiment = sentimentNode.asText();
					// Azureのmixedはnegativeに変換（仕様による）
					if ("mixed".equalsIgnoreCase(sentiment)) {
						return "negative";
					}
					return sentiment;
				}
			}
		} catch (Exception e) {
			e.printStackTrace(); // 本番環境ではロギングに置き換え推奨
		}
		return "neutral"; // エラー時はニュートラル扱い
	}

	/**
	 * メソッド名: showSuccessPage
	 * 投稿成功後の完了画面を表示します。
	 *
	 * @param review 投稿されたレビューのオブジェクト
	 * @param model Viewに渡すためのModelオブジェクト
	 * @return String ビュー名（"submitSuccess"を返し、submitSuccess.htmlを表示）
	 */
	@GetMapping("/submitSuccess")
	public String showSuccessPage(@ModelAttribute("review") review review, Model model) {
		model.addAttribute("review", review);
		return "submitSuccess";//成功画面の表示する。
	}

	/**
	 * メソッド名: submitReview
	 * レビュー投稿処理を行います。バリデーション、NGワードチェック、カテゴリ判定、感情分析を行いDB保存します。
	 *
	 * @param age 年齢
	 * @param gender 性別
	 * @param product 商品名
	 * @param star 評価星（任意）
	 * @param reviewText レビュー本文
	 * @param model Viewに渡すためのModelオブジェクト
	 * @return String 遷移先ビュー名（エラー時は"reviewForm"、成功時は"submitSuccess"）
	 */
	@PostMapping("/submit")
	public String submitReview(
			@RequestParam("age") Integer age,
			@RequestParam("gender") String gender,
			@RequestParam("product") String product,
			@RequestParam("category") String category,
			@RequestParam(value = "star", required = false) Integer star,
			@RequestParam("review") String reviewText,
			Model model) {

		// 年齢チェック
		if (age < 15 || age > 115) {
			model.addAttribute("error", "不適切な年齢です");
			return "reviewForm"; // 入力フォームに戻る
		}

		//文字数チェック
		if (reviewText.length() < 5 || reviewText.length() > 200) {
			model.addAttribute("error", "レビューは5文字以上200文字以内で入力してください。");
			return "reviewForm"; // 入力フォームに戻る
		}

		// NGワードリスト（不適切語や宣伝用語など）
		List<String> ngWords = List.of(
				"ああああ", "いいいい", "てすと", "test", "123", "ｗｗｗ", "qwerty", "asdfgh", "無意味",
				"くそ", "ばか", "アホ", "死ね", "消えろ", "詐欺", "殺す", "カス",
				"ブス", "デブ", "チビ", "ジジイ", "ババア", "外人", "キモい",
				"エロ", "アダルト", "セックス", "変態", "暴力", "殺人", "自殺", "テロ",
				"馬鹿にしてる", "頭おかしい", "精神病", "障害者", "メンヘラ", "ニート", "無能",
				"http://", "https://", "www.", "click", "お金稼げる", "副業", "LINE交換", "Instagramフォロー",
				"チート", "ハック");

		// NGワードが含まれていればエラーを返す
		for (String ng : ngWords) {
			if (reviewText.toLowerCase().contains(ng.toLowerCase())) {
				model.addAttribute("error", "レビュー内容が不適切です。もう一度確認してください。");
				return "reviewForm";
			}
		}

		// --- 自動カテゴリ判定と感情分析 ---

		String sentiment = analyzeSentiment(reviewText);

		// --- レビューEntityを作成し値セット ---
		review newReview = new review();
		newReview.setAge(age);
		newReview.setGender(gender);
		newReview.setProduct(product);
		newReview.setStar(star);
		newReview.setReview(reviewText);
		newReview.setCategory(category);
		newReview.setSentiment(sentiment);
		newReview.setDate(LocalDate.now());

		// --- DBへ保存 ---
		reviewRepository.save(newReview);

		// --- 完了画面へ渡すモデルにセット ---
		model.addAttribute("review", newReview);
		return "submitSuccess"; // 投稿完了画面に遷移
	}
}