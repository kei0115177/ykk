package com.example.demo.service;

import java.util.List;

public interface ProductService {
    List<String> getProductsByCategory(String category);
    List<String> getAllCategories(); 
}
