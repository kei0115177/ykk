package com.example.demo.controller;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.example.demo.Entity.review;
import com.example.demo.repository.reviewRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class reviewController02 {

    private final reviewRepository reviewRepository;

    private final String AZURE_ENDPOINT = "https://bunnseki01.cognitiveservices.azure.com/";
    private final String AZURE_KEY = "5zB3UvMufpMCPzYmX4fTNYdSIj6wZBSxISlWmU5N5woHq8h6wmYNJQQJ99BFACYeBjFXJ3w3AAAaACOGdPMC";

    public reviewController02(reviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    @GetMapping("/reviewForm")
    public String showForm(@RequestParam(required = false) String success, Model model) {
        if (success != null) {
            model.addAttribute("message", "レビューを投稿しました！");
        }
        return "reviewForm";
    }

  

    private String categorizeProduct(String product) {
        Map<String, List<String>> map = new HashMap<>();
        map.put("家電", List.of("テレビ", "冷蔵庫", "エアコン", "電子レンジ", "掃除機"));
        map.put("日用品", List.of("シャンプー", "洗剤", "ティッシュ", "歯ブラシ"));
        map.put("食品", List.of("チョコレート", "インスタントラーメン", "ジュース", "コーヒー"));
        map.put("ファッション", List.of("シャツ", "靴", "バッグ", "腕時計"));
        map.put("家具", List.of("椅子", "ソファ", "机", "ベッド"));

        String lower = product.toLowerCase();
        for (var entry : map.entrySet()) {
            for (String keyword : entry.getValue()) {
                if (lower.contains(keyword.toLowerCase())) {
                    return entry.getKey();
                }
            }
        }
        return "その他";
    }

    private String analyzeSentiment(String text) {
        try {
            RestTemplate restTemplate = new RestTemplate();
            String url = AZURE_ENDPOINT + "/text/analytics/v3.1/sentiment";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Ocp-Apim-Subscription-Key", AZURE_KEY);

            String body = "{ \"documents\": [ { \"id\": \"1\", \"language\": \"ja\", \"text\": \"" 
                    + text.replace("\"", "\\\"") + "\" } ] }";

            HttpEntity<String> entity = new HttpEntity<>(body, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode root = mapper.readTree(response.getBody());
                JsonNode sentimentNode = root.path("documents").get(0).path("sentiment");
                if (!sentimentNode.isMissingNode()) {
                    String sentiment = sentimentNode.asText();
                    if ("mixed".equalsIgnoreCase(sentiment)) {
                        return "negative";
                    }
                    return sentiment;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "neutral";
    }
    
	@PostMapping("/submit")
	public String submitReview(
	        @RequestParam("age") Integer age,
	        @RequestParam("gender") String gender,
	        @RequestParam("product") String product,
	        @RequestParam(value = "star", required = false) Integer star,
	        @RequestParam("review") String reviewText,
	        Model model) {

	    // --- バリデーション ---
	    if (age < 15 || age > 115) {
	        model.addAttribute("error", "不適切な年齢です");
	        return "reviewForm";
	    }

	    if (reviewText.length() < 5 || reviewText.length() > 200) {
	        model.addAttribute("error", "レビューは5文字以上200文字以内で入力してください。");
	        return "reviewForm";
	    }

	    List<String> ngWords = List.of(
	    	    "ああああ", "いいいい", "てすと", "test", "123", "ｗｗｗ", "qwerty", "asdfgh",  "無意味",
	    	    "くそ", "ばか", "アホ", "ゴミ", "死ね", "消えろ", "詐欺", "殺す", "カス", 
	    	    "ブス", "デブ", "チビ", "ジジイ", "ババア", "外人", "キモい",
	    	    "エロ", "アダルト", "セックス", "変態", "暴力", "殺人", "自殺", "テロ",
	    	    "馬鹿にしてる", "頭おかしい", "精神病", "障害者", "メンヘラ", "ニート", "無能",
	    	    "http://", "https://", "www.", "click", "お金稼げる", "副業", "LINE交換", "Instagramフォロー",
	    	    "チート", "ハック"
	    	);

	    for (String ng : ngWords) {
	        if (reviewText.toLowerCase().contains(ng.toLowerCase())) {
	            model.addAttribute("error", "レビュー内容が不適切です。もう一度確認してください。");
	            return "reviewForm";
	        }
	    }

	    // --- 自動分類・感情分析 ---
	    String category = categorizeProduct(product);
	    String sentiment = analyzeSentiment(reviewText);

	    // --- レビュー作成 ---
	    review newReview = new review();
	    newReview.setAge(age);
	    newReview.setGender(gender);
	    newReview.setProduct(product);
	    newReview.setStar(star);
	    newReview.setReview(reviewText);
	    newReview.setCategory(category);
	    newReview.setSentiment(sentiment);
	    newReview.setDate(LocalDate.now());

	    // --- 保存 ---
	    reviewRepository.save(newReview);

	    // --- 完了画面にレビューを渡す ---
	    model.addAttribute("review", newReview);
	    return "submitSuccess";  // submitSuccess.html に遷移して内容を表示
	}
}
