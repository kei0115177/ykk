package com.example.demo.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.Entity.review;
import com.example.demo.repository.reviewRepository;

@Controller
public class reviewController {

	private final reviewRepository reviewRepository;

	public reviewController(reviewRepository reviewRepository) {
		this.reviewRepository = reviewRepository;
	}

	@GetMapping("/reviews")
	public String showReviewList(
			@RequestParam(required = false) String category,
			@RequestParam(required = false) String sentiment,
			@RequestParam(required = false) String keyword,
			@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
			@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
			Model model) {

		boolean isSearched = (StringUtils.hasText(category) ||
				StringUtils.hasText(sentiment) ||
				StringUtils.hasText(keyword) ||
				fromDate != null || toDate != null);

		model.addAttribute("isSearched", isSearched);

		// 検索されていないときはレビューを表示しない
		if (!isSearched) {
			model.addAttribute("reviews", null);
			model.addAttribute("sentimentCounts", List.of(0L, 0L, 0L)); // グラフが壊れないよう空データも渡す
			return "reviewList";
		}

		// 全レビュー取得
		List<review> reviews = reviewRepository.findAll();

		// フィルター処理
		if (StringUtils.hasText(category)) {
			reviews = reviews.stream()
					.filter(r -> category.equalsIgnoreCase(r.getCategory()))
					.collect(Collectors.toList());
		}

		if (StringUtils.hasText(sentiment)) {
			reviews = reviews.stream()
					.filter(r -> sentiment.equalsIgnoreCase(r.getSentiment()))
					.collect(Collectors.toList());
		}

		if (fromDate != null) {
			reviews = reviews.stream()
					.filter(r -> r.getDate() != null && !r.getDate().isBefore(fromDate))
					.collect(Collectors.toList());
		}

		if (toDate != null) {
			reviews = reviews.stream()
					.filter(r -> r.getDate() != null && !r.getDate().isAfter(toDate))
					.collect(Collectors.toList());
		}

		if (StringUtils.hasText(keyword)) {
			String lowerKeyword = keyword.toLowerCase();
			reviews = reviews.stream()
					.filter(r -> r.getReview() != null && r.getReview().toLowerCase().contains(lowerKeyword))
					.collect(Collectors.toList());
		}

		model.addAttribute("reviews", reviews);

		// グラフ用：感情を小文字に正規化して件数集計
		Map<String, Long> sentimentCountsMap = reviews.stream()
				.filter(r -> r.getSentiment() != null)
				.collect(Collectors.groupingBy(
						r -> r.getSentiment().toLowerCase(),
						Collectors.counting()
				));

		List<Long> sentimentCountList = List.of(
				sentimentCountsMap.getOrDefault("positive", 0L),
				sentimentCountsMap.getOrDefault("neutral", 0L),
				sentimentCountsMap.getOrDefault("negative", 0L)
		);
		model.addAttribute("sentimentCounts", sentimentCountList);

		return "reviewList";
	}

	@PostMapping("/reviews/delete/{id}")
	public String deleteReview(@PathVariable Long id) {
		reviewRepository.deleteById(id);
		return "redirect:/reviews";
	}
}

