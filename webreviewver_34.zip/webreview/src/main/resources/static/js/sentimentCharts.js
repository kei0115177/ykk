/**
 * 
 */
document.addEventListener('DOMContentLoaded', () => {
	if (typeof sentimentCounts === 'undefined') return;

	// 棒グラフ
	const ctx = document.getElementById('sentimentChart')?.getContext('2d');
	if (ctx) {
		new Chart(ctx, {
			type: 'bar',
			data: {
				labels: ['Positive', 'Neutral', 'Negative'],
				datasets: [{
					label: 'レビュー件数',
					data: sentimentCounts,
					backgroundColor: [
						'rgba(54, 162, 235, 0.7)',
						'rgba(201, 203, 207, 0.7)',
						'rgba(255, 99, 132, 0.7)'
					],
					borderColor: [
						'rgba(54, 162, 235, 1)',
						'rgba(201, 203, 207, 1)',
						'rgba(255, 99, 132, 1)'
					],
					borderWidth: 1
				}]
			},
			options: {
				scales: {
					y: {
						beginAtZero: true,
						title: {
							display: true,
							text: 'レビュー件数'
						}
					}
				}
			}
		});
	}

	// 円グラフ
	const pieCtx = document.getElementById('sentimentPieChart')?.getContext('2d');
	if (pieCtx) {
		const total = sentimentCounts.reduce((a, b) => a + b, 0);

		new Chart(pieCtx, {
			type: 'pie',
			data: {
				labels: ['Positive', 'Neutral', 'Negative'],
				datasets: [{
					label: '割合',
					data: sentimentCounts,
					backgroundColor: [
						'rgba(54, 162, 235, 0.7)',
						'rgba(201, 203, 207, 0.7)',
						'rgba(255, 99, 132, 0.7)'
					],
					borderColor: ['white', 'white', 'white'],
					borderWidth: 2
				}]
			},
			options: {
				plugins: {
					legend: {
						position: 'right'
					},
					datalabels: {
						formatter: (value) => {
							return total ? `${Math.round((value / total) * 100)}%` : '';
						},
						color: '#000',
						font: {
							weight: 'bold'
						}
					}
				}
			},
			plugins: [ChartDataLabels]
		});
	}
});
