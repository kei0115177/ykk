package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller // Spring MVC のコントローラーとしてマーク
public class LoginController {

    // GETリクエストで /login にアクセスがあったときに実行される
    @GetMapping("/login")
    public String login() {
        // resources/templates/login.html を表示する
        return "login";
    }
}
