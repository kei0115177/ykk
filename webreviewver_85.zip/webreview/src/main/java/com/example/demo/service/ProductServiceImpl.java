package com.example.demo.service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class ProductServiceImpl implements ProductService {

    private static final Map<String, List<String>> CATEGORY_MAP = Map.of(
        "家電", List.of("テレビ", "冷蔵庫", "エアコン", "電子レンジ", "掃除機"),
        "日用品", List.of("シャンプー", "洗剤", "ティッシュ", "歯ブラシ"),
        "食品", List.of("チョコレート", "インスタントラーメン", "ジュース", "コーヒー"),
        "ファッション", List.of("シャツ", "靴", "バッグ", "腕時計"),
        "家具", List.of("椅子", "ソファ", "机", "ベッド")
    );

    @Override
    public List<String> getProductsByCategory(String category) {
        return CATEGORY_MAP.getOrDefault(category, List.of());
    }
    @Override
    public List<String> getAllCategories() {
        return Arrays.asList("家電", "日用品", "食品", "ファッション", "家具");
    }
}
