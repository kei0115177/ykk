package com.example.demo.config;

// 必要なSpringやセキュリティ関連のクラスをインポート
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration // Springの設定クラスであることを示すアノテーション
@EnableWebSecurity // Webセキュリティ機能を有効にする
public class SecurityConfig {

    // セキュリティ設定の中核となるBean
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http
            // URLごとのアクセス制御の設定
            .authorizeHttpRequests(authz -> authz
                // これらのURLは誰でもアクセス可能（ログイン不要）
                .requestMatchers("/submit", "/reviewForm").permitAll()
                
                // 下記URLにアクセスするには認証が必要
                .requestMatchers("/reviews/**", "/reviews", "/reviewListf", "/reviewf").authenticated()

                // その他のすべてのリクエストは許可（permitAll）←注意
                .anyRequest().permitAll()
            )

            // ログインフォームの設定
            .formLogin(form -> form
                // カスタムログインページのパス
                .loginPage("/login")
                
                // ログイン成功後にリダイレクトされる先（true指定で常にこのURLへ）
                .defaultSuccessUrl("/reviewListf", true)

                // ログイン関連のパスは誰でもアクセス可能
                .permitAll()
            )

            // ログアウトの設定
            .logout(logout -> logout
                // ログアウト処理のURL
                .logoutUrl("/logout")

                // ログアウト後にリダイレクトされる先
                .logoutSuccessUrl("/login?logout")

                // セッションを無効化してセキュリティを高める
                .invalidateHttpSession(true)

                // クッキー（JSESSIONID）も削除してセッション完全破棄
                .deleteCookies("JSESSIONID")
            )

            // CSRF（クロスサイトリクエストフォージェリ）対策はデフォルト有効
            .csrf(Customizer.withDefaults())

            // 最終的に設定をビルドして返す
            .build();
    }

    // パスワードのハッシュ化に使うエンコーダーのBean定義（BCrypt方式）
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

   
}
