package com.example.demo.service;

import java.util.List;

public interface ProductService {

    // 指定されたカテゴリに属する商品リストを返す
    List<String> getProductsByCategory(String category);

    // 全カテゴリの一覧を返す
    List<String> getAllCategories();
}
