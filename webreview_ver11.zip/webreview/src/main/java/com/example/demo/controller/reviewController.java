package com.example.demo.controller;

import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.Entity.review;
import com.example.demo.repository.reviewRepository;

@Controller
public class reviewController {

	private final reviewRepository reviewRepository;

	public reviewController(reviewRepository reviewRepository) {
		this.reviewRepository = reviewRepository;
	}

	@GetMapping("/reviews")
	public String showReviewList(
			@RequestParam(required = false) String category,
			@RequestParam(required = false) String sentiment,
			@RequestParam(required = false) String keyword,
			@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
			@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate,
			Model model) {

		boolean isSearched = (StringUtils.hasText(category) ||
				StringUtils.hasText(sentiment) ||
				StringUtils.hasText(keyword) ||
				fromDate != null || toDate != null);

		model.addAttribute("isSearched", isSearched);

		// 検索されていないときはレビューを表示しない
		if (!isSearched) {
			model.addAttribute("reviews", null);
			model.addAttribute("sentimentCounts", List.of(0L, 0L, 0L)); // グラフが壊れないよう空データも渡す
			return "reviewList";
		}

		// 全レビュー取得
		List<review> reviews = reviewRepository.findAll();

		// フィルター処理
		if (StringUtils.hasText(category)) {
			reviews = reviews.stream()
					.filter(r -> category.equalsIgnoreCase(r.getCategory()))
					.collect(Collectors.toList());
		}

		if (StringUtils.hasText(sentiment)) {
			reviews = reviews.stream()
					.filter(r -> sentiment.equalsIgnoreCase(r.getSentiment()))
					.collect(Collectors.toList());
		}

		if (fromDate != null) {
			reviews = reviews.stream()
					.filter(r -> r.getDate() != null && !r.getDate().isBefore(fromDate))
					.collect(Collectors.toList());
		}

		if (toDate != null) {
			reviews = reviews.stream()
					.filter(r -> r.getDate() != null && !r.getDate().isAfter(toDate))
					.collect(Collectors.toList());
		}

		if (StringUtils.hasText(keyword)) {
			String lowerKeyword = keyword.toLowerCase();
			reviews = reviews.stream()
					.filter(r -> r.getReview() != null && r.getReview().toLowerCase().contains(lowerKeyword))
					.collect(Collectors.toList());
		}

		model.addAttribute("reviews", reviews);

		// グラフ用：感情を小文字に正規化して件数集計
		Map<String, Long> sentimentCountsMap = reviews.stream()
				.filter(r -> r.getSentiment() != null)
				.collect(Collectors.groupingBy(
						r -> r.getSentiment().toLowerCase(),
						Collectors.counting()
				));

		List<Long> sentimentCountList = List.of(
				sentimentCountsMap.getOrDefault("positive", 0L),
				sentimentCountsMap.getOrDefault("neutral", 0L),
				sentimentCountsMap.getOrDefault("negative", 0L)
		);
		model.addAttribute("sentimentCounts", sentimentCountList);

		// 性別ごとの感情件数（昇順）
		Map<String, Map<String, Long>> genderSentimentMap = reviews.stream()
				.collect(Collectors.groupingBy(
						r -> r.getGender() != null ? r.getGender().toLowerCase() : "unknown",
						TreeMap::new,
						Collectors.groupingBy(
								r -> r.getSentiment().toLowerCase(),
								Collectors.counting()
						)
				));

		// 年代順定義
		Map<String, Integer> ageOrder = Map.of(
				"10代以下", 1,
				"20代", 2,
				"30代", 3,
				"40代", 4,
				"50代", 5,
				"60代", 6,
				"70代", 7,
				"80代以上", 8
		);

		// 年代ごとの感情件数（年代昇順に並べる）
		Map<String, Map<String, Long>> tempAgeMap = reviews.stream()
				.collect(Collectors.groupingBy(
						r -> {
							int age = r.getAge() != null ? r.getAge() : 0;
							if (age < 20) return "10代以下";
							else if (age < 30) return "20代";
							else if (age < 40) return "30代";
							else if (age < 50) return "40代";
							else if (age < 60) return "50代";
							else if (age < 70) return "60代";
							else if (age < 80) return "70代";
							else return "80代以上";
						},
						Collectors.groupingBy(
								r -> r.getSentiment().toLowerCase(),
								Collectors.counting()
						)
				));

		Map<String, Map<String, Long>> ageGroupSentimentMap = new LinkedHashMap<>();
		tempAgeMap.entrySet().stream()
				.sorted(Map.Entry.comparingByKey((a, b) -> ageOrder.getOrDefault(a, 99) - ageOrder.getOrDefault(b, 99)))
				.forEachOrdered(e -> ageGroupSentimentMap.put(e.getKey(), e.getValue()));

		model.addAttribute("genderSentimentMap", genderSentimentMap);
		model.addAttribute("ageGroupSentimentMap", ageGroupSentimentMap);

		return "reviewList";
	}

	@PostMapping("/reviews/delete/{id}")
	public String deleteReview(@PathVariable Long id) {
		reviewRepository.deleteById(id);
		return "redirect:/reviews";
	}
}
