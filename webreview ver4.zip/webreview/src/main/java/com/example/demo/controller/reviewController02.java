package com.example.demo.controller;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.example.demo.Entity.review;
import com.example.demo.repository.reviewRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class reviewController02 {

    private final reviewRepository reviewRepository;

    private final String AZURE_ENDPOINT = "https://bunnseki01.cognitiveservices.azure.com/";
    private final String AZURE_KEY = "5zB3UvMufpMCPzYmX4fTNYdSIj6wZBSxISlWmU5N5woHq8h6wmYNJQQJ99BFACYeBjFXJ3w3AAAaACOGdPMC";

    public reviewController02(reviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    @GetMapping("/reviewForm")
    public String showForm(@RequestParam(required = false) String success, Model model) {
        if (success != null) {
            model.addAttribute("message", "レビューを投稿しました！");
        }
        return "reviewForm";
    }

    @PostMapping("/submit")
    public String submitReview(
            @RequestParam Integer age,
            @RequestParam String gender,
            @RequestParam String product,
            @RequestParam(required = false) Integer star,
            @RequestParam String review,
            Model model) {

        // バリデーション
        if (age < 0 || age > 115) {
            model.addAttribute("error", "年齢は0〜115の間で入力してください。");
            return "reviewForm";
        }

        if (review.length() < 10 || review.length() > 200) {
            model.addAttribute("error", "レビューは10文字以上200文字以内で入力してください。");
            return "reviewForm";
        }

        List<String> ngWords = List.of("ああああ", "てすと", "test", "123", "無効", "意味ない");
        for (String ng : ngWords) {
            if (review.toLowerCase().contains(ng.toLowerCase())) {
                model.addAttribute("error", "レビュー内容が不適切です。もう一度確認してください。");
                return "reviewForm";
            }
        }

        // 自動分類・感情分析
        String category = categorizeProduct(product);
        String sentiment = analyzeSentiment(review);

        // 保存
        review rev = new review();
        rev.setAge(age);
        rev.setGender(gender);
        rev.setProduct(product);
        rev.setStar(star);
        rev.setReview(review);
        rev.setCategory(category);
        rev.setSentiment(sentiment);
        rev.setDate(LocalDate.now());

        reviewRepository.save(rev);

        return "redirect:/reviewForm?success=true";
    }

    private String categorizeProduct(String product) {
        Map<String, List<String>> map = new HashMap<>();
        map.put("家電", List.of("テレビ", "冷蔵庫", "エアコン", "電子レンジ", "掃除機"));
        map.put("日用品", List.of("シャンプー", "洗剤", "ティッシュ", "歯ブラシ"));
        map.put("食品", List.of("チョコレート", "インスタントラーメン", "ジュース", "コーヒー"));
        map.put("ファッション", List.of("シャツ", "靴", "バッグ", "腕時計"));
        map.put("家具", List.of("椅子", "ソファ", "机", "ベッド"));

        String lower = product.toLowerCase();
        for (var entry : map.entrySet()) {
            for (String keyword : entry.getValue()) {
                if (lower.contains(keyword.toLowerCase())) {
                    return entry.getKey();
                }
            }
        }
        return "その他";
    }

    private String analyzeSentiment(String text) {
        try {
            RestTemplate restTemplate = new RestTemplate();
            String url = AZURE_ENDPOINT + "/text/analytics/v3.1/sentiment";

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Ocp-Apim-Subscription-Key", AZURE_KEY);

            String body = "{ \"documents\": [ { \"id\": \"1\", \"language\": \"ja\", \"text\": \"" 
                    + text.replace("\"", "\\\"") + "\" } ] }";

            HttpEntity<String> entity = new HttpEntity<>(body, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);

            if (response.getStatusCode() == HttpStatus.OK) {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode root = mapper.readTree(response.getBody());
                JsonNode sentimentNode = root.path("documents").get(0).path("sentiment");
                if (!sentimentNode.isMissingNode()) {
                    return sentimentNode.asText();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "neutral";
    }
}
