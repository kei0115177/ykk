/**
 * 
 */
function buildStackedChart(ctxId, dataMap, title) {
	const labels = Object.keys(dataMap);
	const sentiments = ['positive', 'neutral', 'negative'];
	const datasets = sentiments.map((sentiment, i) => ({
		label: sentiment,
		data: labels.map(label => dataMap[label]?.[sentiment] || 0),
		backgroundColor: ['#4caf50', '#9e9e9e', '#f44336'][i]
	}));

	new Chart(document.getElementById(ctxId), {
		type: 'bar',
		data: {
			labels: labels,
			datasets: datasets
		},
		options: {
			plugins: {
				title: {
					display: true,
					text: title
				}
			},
			responsive: true,
			scales: {
				x: { stacked: true },
				y: { stacked: true, beginAtZero: true }
			}
		}
	});
}

// ページ読み込み後にグラフ描画を実行
document.addEventListener('DOMContentLoaded', () => {
	if (typeof genderData !== 'undefined' && typeof ageData !== 'undefined') {
		buildStackedChart("genderChart", genderData, "性別ごとの感情傾向");
		buildStackedChart("ageChart", ageData, "年齢層ごとの感情傾向");
	}
});
