package com.example.demo.Entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity // JPAのエンティティ（DBのテーブルに対応するJavaクラス）
@Table(name = "reviews") // このクラスは "reviews" テーブルにマッピングされる
@Getter // Lombok: getterを自動生成
@Setter // Lombok: setterを自動生成
public class review {

    @Id // 主キー（プライマリキー）
    @GeneratedValue(strategy = GenerationType.IDENTITY) // MySQLなどのauto_incrementに相当
    private Long id;

    // レビュワーの年齢（年代別グラフに使用）
    private Integer age;

    // 性別（グラフ用やフィルタ条件）
    private String gender;

    // カテゴリ（例: 電化製品・食品など）
    private String category;

    // 商品名
    private String product;

    // 星の評価（1〜5など）
    private Integer star;

    // レビュー本文
    private String review;

    // 感情（例: positive / neutral / negative）
    private String sentiment;

    // レビュー投稿日（検索条件にも使う）
    private LocalDate date;
}
